# kodi-swefilm

[![Build Status](https://travis-ci.org/daniel-lundin/kodi-swefilm.svg?branch=master)](https://travis-ci.org/daniel-lundin/kodi-swefilm)
Unofficial kodi addon for streaming from swefilm.tv.

Functionality is very limited at the moment.

[MIT License](LICENSE.txt) © 2015 Daniel Lundin (http://twitter.com/danielundin).
